import {CHANGE_SEARCH_FIELD} from './contants.js';
export const setSearchField=(text) =>
({
    type: CHANGE_SEARCH_FIELD,//it is capitalize beacuse it is a constant and constant is capitalize in js
    payload: text
})