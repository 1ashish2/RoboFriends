import {CHANGE_SEARCH_FIELD} from './contants.js';

const intialState ={
    searchField:''
}

export const searchRobots = (state=intialState,action = {})=>{
    //here state is initial state that have search field is empty
    //here action having empty that is define in action.js
    switch(action.type)
    {
        case CHANGE_SEARCH_FIELD:
         
            return Object.assign({},state, searchField: action.payload);
        //here we r returning a new state with object.assign
        //that's going to have everything in the state
        //plus we are going to update whatever search field
        //property,new search field property we have with action.payload
        //action has two things that were sending object with type
        //and object with payload
        //so this is simply saying we recieved an action called CHANGE_SEARCHFIELD
        //this is the standard redux syntax that's we used
        default:
            return state;
        // so action type is not this we also want to say default to always just return state

        /* another option is to do OBJECT DESTRUCTURING or OBJECT SPREAD
        operator which means that we can do somthing like this */
        
        //return {...state, searchField:action.payload}

        //a pure funct return something
    }
}