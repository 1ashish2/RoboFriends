export const robots=[

    {
        id:1,
        name:'Ashish',
        email:'ashish@gmail.com'
    },
    
    {
        id:2,
        name:'Ayush',
        email:'ayush@gmail.com'
    },

    { 
        id:3,
        name:'Ak',
        email:'ak@gmail.com'
    },
    
    {
        id:4,
        name:'kajal',
        email:'kajal@gmail.com'
    },
    
    {
        id:5,
        name:'Dhanno',
        email:'dhanno@gmail.com'
    },
    
    {
        id:6,
        name:'aish',
        email:'aish@gmail.com'
    },
    
    {
        id:7,
        name:'Moti',
        email:'moti@gmail.com'
    },
    
    {
        id:8,
        name:'Kammo',
        email:'kammo@gmail.com'
    }
];