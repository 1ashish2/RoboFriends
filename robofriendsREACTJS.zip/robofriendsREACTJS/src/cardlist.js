import React from 'react';
import App from './practise';
//import {robots} from './robot';

const cardlist=({robots})=>
{  
       /* if(true)
        {
            throw new Error('Nooooooo!');
        }*/
    
    const cardArray=robots.map((user,i)=>
    {
        return( <App 
        key={i} 
        id={robots[i].id}
         name={robots[i].name}
          email={robots[i].email} />
        );
    })
    return(
        <div>
       {cardArray}     
        </div>

    );
}
export default cardlist;