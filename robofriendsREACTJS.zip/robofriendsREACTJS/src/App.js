import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
//import {robots} from './robot';
import Cardlist from './cardlist';
import Searchbox from './Searchbox';
//import { robots } from './robot';
import Scroll from './Scroll';
import ErrorBoundry from './ErrorBoundry';


export default class App extends Component {
  constructor()
  {
    super();
    this.state={
      robots:[],
      searchfield: ''
    }
  }
  componentDidMount()
  {
    fetch('https://jsonplaceholder.typicode.com/users').then(response =>{
   return response.json();
  }).then(users =>{
    this.setState({robots:users});
  });
   
  }
 onSearchChange=(event) =>
 {
    this.setState({searchfield:event.target.value});
   // console.log(filtering);
 }
  render(){
    const filtering=this.state.robots.filter(robots=>{
      return robots.name.toLowerCase().includes(this.state.searchfield.toLowerCase());
  })
  if(this.state.robots.length ===0)
  { 
    return <h1>Loading.....</h1>
  }else
  {
  return (
    <div className='tc' >
      <h1 className="f1">Welcome to Robo Friends</h1>
      <Searchbox searchChange={this.onSearchChange}/>
      <Scroll>
        <ErrorBoundry>
    <Cardlist robots={filtering}/>
    </ErrorBoundry>
    </Scroll>
    </div> 
); 
  }
}
} 


