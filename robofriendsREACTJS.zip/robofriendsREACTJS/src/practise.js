import React from 'react';


//const practise = (props) => {
    //const {id,name,email}= props;
    const practise = ({id,name,email}) => {
    return (
        <div className="tc bg-light-green dib br3 pa2 ma2 shrink bw2 shadow-5">
         <img alt="robo pic" src={`https://robohash.org/${id}?set=set4` }/>
                <div>
                    <h5>{name}</h5>
                    <p>{email}</p>
                </div>
            </div>
    );
}
export default practise;    